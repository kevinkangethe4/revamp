<!doctype html>
<html>
<title>aboutus|REVAMP Dry-Cleaner And Laundry Services</title>
<STYLE>
.navbar {
  overflow: hidden;
  background-color: white;
}

.navbar a {
  float: left;
  font-size: 11px;
  color: white;
  text-align: left;
  padding: 10px 12px;
  text-decoration: none;border-style:ridge;border-color:red;font-family:bold;
}

.dropdown {
  float: left;
  overflow: hidden;
  border-style:ridge;border-color:red;
  
}
.dropbtn {background-color: lightgreen;background:url(exa.png);
  color: red;
  padding: 30px;
  font-size: 7px;
  border: none;
  cursor: pointer;
  
}
.dropdown .dropbtn {
  font-size: 12px;  
  border: none;
  outline: none;
  color: white;
  padding: 7px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: lightgrey;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 100px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: white;
  padding: 6px 12px;
  text-decoration: none;
  display: block;
  text-align: left;
  
  border-style:ridge;border-color:red;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

img.center{display:block;margin:0 auto;}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: white;
    position: fixed;
    top: 20;
    width: 100%;
}
li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color: lightgrey;
}

.active {
    background

</STYLE>
<ul>
<link rel="stylesheet" href="roan1.css">
<link rel="shortcut icon" href="p/rd.ico" width="100px"/>

<div>

<table width="980px">
<tr>
<td style=text-align:center;color:white;><img src="PH.PNG" WIDTH="20PX"> +254 720 733 828 /+254 202 189 437 |<img src="E.PNG" WIDTH="20PX">revampdryc@gmail.com</td>
<td><img src="f.png" width="40px"><img src="twi.png" width="40px"><img src="g.png" width="24px"></td>
</tr>
</table>
</div>

<body>
<table width="1000px" align="center">

<td style="text-align:center;">   <img src="pic/re.png" width="350px" height="170px" align="middle"></td>
<td><div class="navbar">
  <a href="home.php">Home</a>
  <a href="aboutus.php">About Us</a>
  <div class="dropdown">
    <button class="dropbtn"><img src ="pic/U.png" width="15px" align="right">Dry-Cleaning Service's 
    </button>
    <div class="dropdown-content" style=text-align:left;>
	<ul>
     <li> <a href="ss.php">Suit Cleaning</a></li>
     <li><a href="cs.php">Curtain Cleaning</a></li>
     <li> <a href="cdc.php">Comforter And Duvet Cleaning</a></li>
	 <br>
	 <br>
	 
	 <li> <a href="sp.php">Steaming and Pressing</a><li>
	  <li><a href="dc.php">Dry-Cleaning</a></li>
	  <li><a href="lss.php">Laundered Shirt Service </a></li>
	  <br>
	  <br>
	  <li><a href="lc.php">Leather Cleaning</a></li>
	 <li><a href="ssc.php">Sport Shoe Cleaning</a></li>
	  <li><a href="gc.php">Gown Cleaning </a></li>
	  <br>
	  <br>
	  <li><a href="uni.php">Uniform's Cleaning Service's</a></li>
	 <li><a href="tw.php">Towel's Cleaning Service's</a></li>
	  </ul>
    </div>
  </div> 
  <a href="Fs.php">Fumigation and Pest Control Service's</a>
   <a href="wu.php">Why Us</a>
    <a href="cu.php">Contacts</a>
	
</div>

</td>

</table>
</ul>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</table>
<div style=background-image:url("p/a.jpg")>
<h1>About US
<br>
<br>
</h1>
</div>
<H2 STYLE=FONT-SIZE:15PX;color:red;>Who We Are?


</h2>
<br>
 <H2 STYLE=FONT-SIZE:15PX;>

REVAMP Dry Cleaners has been setting the standard for quality garment care and Pest control. Our mission is to provide consistent quality clothing care with knowledgeable and friendly service. Dry cleaning is a daunting chore so at REVAMP, we endeavor to  make your visit as quick and easy as possible without compromising quality and service.

 

The dry cleaning technology used at REVAMP complies with the most stringent international standards to ensure that your garments will be restored to a standard appearance that rivals new clothes. This kind of an almost obsessive attention to detail is what our work and service ethics are based on.

 
</H2>
<H2 STYLE=FONT-SIZE:15PX;color:red;>
Why we're DIFFERENT?

</h2>

 <H2 STYLE=FONT-SIZE:15PX;>

We realize and appreciate the investment you’ve made in your wardrobe. That is why your clothing will always undergo our

7-POINT CHECK PROCESS while in our care. Our specialized inspection starts the minute we receive your garments. We check

 for spots, stains, cracked or missing buttons and loose threads some of which we repair for free.

 

Your health and the environment are a major concern to us. That is why we have invested in internationally certified solvents, detergents and machinery for all our washes. Our cleaning agents are Eco-friendly and Hypoallergenic to ensure safety to health and nature as well.

 

Our garment experts have, over the years perfected service delivery and customer relations owing to a specific set of services offered at Flush Dry Cleaners.
</h2>
<div style=background-color:black>
<table width="980px" align="center">
<tr>
<th style=color:red;background-color:white;text-align:center;>Quick Contacts</th>
<th style=color:red; ></th>
<th style=color:red;background-color:white;text-align:center; >Service's</th>
<th style=color:red; ></th>
<th style=color:red;background-color:white; >Social Media</th>
</tr>
<tr><td style=color:white;font-size:12px;>

<h3>
<b>
<li><img src="lo.PNG" WIDTH="20PX"> JOE'S Complex Next to Co-operative <br>Bank-Ruaka Room No:5</li><br>
<li><img src="PH.PNG" WIDTH="20PX"> Phone:+254720733828/+254202189437</li><br>
<li><img src="E.PNG" WIDTH="20PX"> Email:revampdryc@gmail.com</li></td>
<br>
<td style=color:white;font-size:12px;>
<li><a href ="ss.php">Suit Cleaning </a></li><br><br>
<LI><a href ="cs.php">Curtain Cleaning</a></Li><br><br>
<LI><a href ="cdc.php">Comforters And Duvet</a></LI> <br><br>
<li><a href ="sp.php">Steaming and Pressing</a></li><br>
</TD>
<TD style=color:white;font-size:12px; >
<h3>
<li><a href ="dc.php">Dry Cleaning</a></li><br>
<li><a href ="lss.php">Laundered Shirt Service</a></li><br><br>
<li><a href ="fs.php">Fumigation and Pest Control Service's</a></li><br>
<li><a href="uni.php">Uniform's Cleaning Service's</a></li><br>
</td>
<TD style=color:white;font-size:12px; >
<h3>
<li><a href ="lc.php">Leather Cleaning</a></li><br>
<li><a href ="gc.php">Gown Cleaning Services</a></li><br>
<li><a href ="ssc.php">Sport Shoe Cleaning </a></li><br>
<li><a href="tw.php">Towel's Cleaning Service's</a></li>
</h3>
</td>
<td style=color:white;font-size:8px;>
<img src="f.png" width="30px"><h2 style=font-size:5px;>|</h2><img src="twi.png" width="30px"><h2 style=font-size:5px;>|</h2><img src="g.png" width="30px"></td>
</tr>
</table>
</html>
