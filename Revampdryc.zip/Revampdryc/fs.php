<!doctype html>
<html>
<title>fermagationservices|REVAMP Dry-Cleaner And Laundry Services</title>
<STYLE>
.navbar {
  overflow: hidden;
  background-color: white;
}

.navbar a {
  float: left;
  font-size: 11px;
  color: white;
  text-align: left;
  padding: 10px 12px;
  text-decoration: none;border-style:ridge;border-color:red;font-family:bold;
}

.dropdown {
  float: left;
  overflow: hidden;
  border-style:ridge;border-color:red;
  
}
.dropbtn {background-color: lightgreen;background:url(exa.png);
  color: red;
  padding: 30px;
  font-size: 7px;
  border: none;
  cursor: pointer;
  
}
.dropdown .dropbtn {
  font-size: 12px;  
  border: none;
  outline: none;
  color: white;
  padding: 7px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: lightgrey;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 100px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: white;
  padding: 6px 12px;
  text-decoration: none;
  display: block;
  text-align: left;
  
  border-style:ridge;border-color:red;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

img.center{display:block;margin:0 auto;}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: white;
    position: fixed;
    top: 20;
    width: 100%;
}
li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color: lightgrey;
}

.active {
    background

</STYLE>
<ul>
<link rel="stylesheet" href="roan1.css">
<link rel="shortcut icon" href="p/rd.ico" width="100px"/>

<div>

<table width="980px">
<tr>
<td style=text-align:center;color:white;><img src="PH.PNG" WIDTH="20PX"> +254 720 733 828 /+254 202 189 437 |<img src="E.PNG" WIDTH="20PX">revampdryc@gmail.com</td>
<td><img src="f.png" width="40px"><img src="twi.png" width="40px"><img src="g.png" width="24px"></td>
</tr>
</table>
</div>

<body>
<table width="1000px" align="center">

<td style="text-align:center;">  <img src="pic/re.png" width="350px" height="170px" align="middle"></td>
<td><div class="navbar">
  <a href="home.php">Home</a>
  <a href="aboutus.php">About Us</a>
  <div class="dropdown">
    <button class="dropbtn"><img src ="pic/U.png" width="15px" align="right">Dry-Cleaning Service's 
    </button>
    <div class="dropdown-content" style=text-align:left;>
	<ul>
     <li> <a href="ss.php">Suit Cleaning</a></li>
     <li><a href="cs.php">Curtain Cleaning</a></li>
     <li> <a href="cdc.php">Comforter And Duvet Cleaning</a></li>
	 <br>
	 <br>
	 
	 <li> <a href="sp.php">Steaming and Pressing</a><li>
	  <li><a href="dc.php">Dry-Cleaning</a></li>
	  <li><a href="lss.php">Laundered Shirt Service </a></li>
	  <br>
	  <br>
	  <li><a href="lc.php">Leather Cleaning</a></li>
	 <li><a href="ssc.php">Sport Shoe Cleaning</a></li>
	  <li><a href="gc.php">Gown Cleaning </a></li>
	  <br>
	  <br>
	  <li><a href="uni.php">Uniform's Cleaning Service's</a></li>
	 <li><a href="tw.php">Towel's Cleaning Service's</a></li>
	  </ul>
    </div>
  </div> 
  <a href="Fs.php">Fumigation Control Service's</a>
   <a href="wu.php">Why Us</a>
    <a href="cu.php">Contacts</a>
	
</div>

</td>

</table>
</ul>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div style=background-image:url("p/F1.jpg")>
<h1>Fumigation Control Services</h1>
</div>
<h2 style=font-size:15px;>Revamp dry-cleaning Services is a versatile company, we also offer proactive pest control solutions tailored to your individual requirement. We have vast experience in all types of pest problems which gives us a good stead in providing highly effective domestic and commercial solutions.</h2>
<table width="800px" align="center">
<tr>
<td>
<div class="w3-content w3-section" style="max-width:400px">
<img class="mySlides" class="center"src="pic/re.png"style="width:600px;height:300px">
<img class="mySlides" class="center"  src="p/f02.jpg"  style="width:800px;height:300px">
  <img class="mySlides" class="center"src="p/f03.jpg" style="width:800px;height:300px">
  <img class="mySlides" class="center" src="p/f04.jpg"  style="width:800px;height:300px;" >
</td>
</div>
</table>
<script>
var myIndex = 0;
carousel();


function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    

x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>
</div>
<h2 style=font-size:15px;>For instance, we give a 10-year guarantee of a termite free zone after our visit. We take care of cockroaches, sugar ants, bedbugs, termites, woodworm. We provide a fast and efficient pest control service for residential and commercial clients. We are professional, friendly and discreet, offering advice on all aspects of prevention and control of pests. We work with businesses, property managers, schools and a range of community-based organizations.</h2>
<div style=background-color:black>
<table width="980px" align="center">
<tr>
<th style=color:red;background-color:white;text-align:center;>Quick Contacts</th>
<th style=color:red; ></th>
<th style=color:red;background-color:white;text-align:center; >Service's</th>
<th style=color:red; ></th>
<th style=color:red;background-color:white; >Social Media</th>
</tr>
<tr><td style=color:white;font-size:12px;>

<h3>
<b>
<li><img src="lo.PNG" WIDTH="20PX"> JOE'S Complex Next to Co-operative <br>Bank-Ruaka Room No:5</li><br>
<li><img src="PH.PNG" WIDTH="20PX"> Phone:+254720733828/+254202189437</li><br>
<li><img src="E.PNG" WIDTH="20PX"> Email:revampdryc@gmail.com</li></td>
<br>
<td style=color:white;font-size:12px;>
<li><a href ="ss.php">Suit Cleaning </a></li><br><br>
<LI><a href ="cs.php">Curtain Cleaning</a></Li><br><br>
<LI><a href ="cdc.php">Comforters And Duvet</a></LI> <br><br>
<li><a href ="sp.php">Steaming and Pressing</a></li><br>
</TD>
<TD style=color:white;font-size:12px; >
<h3>
<li><a href ="dc.php">Dry Cleaning</a></li><br>
<li><a href ="lss.php">Laundered Shirt Service</a></li><br><br>
<li><a href ="fs.php">Fumigation and Pest Control Service's</a></li><br>
<li><a href="uni.php">Uniform's Cleaning Service's</a></li><br>
</td>
<TD style=color:white;font-size:12px; >
<h3>
<li><a href ="lc.php">Leather Cleaning</a></li><br>
<li><a href ="gc.php">Gown Cleaning Services</a></li><br>
<li><a href ="ssc.php">Sport Shoe Cleaning </a></li><br>
<li><a href="tw.php">Towel's Cleaning Service's</a></li>
</h3>
</td>
<td style=color:white;font-size:8px;>
<img src="f.png" width="30px"><h2 style=font-size:5px;>|</h2><img src="twi.png" width="30px"><h2 style=font-size:5px;>|</h2><img src="g.png" width="30px"></td>
</tr>
</table>
</html>
